/* main.c - FreeRTOS OS Concepts Demo - FIXED VERSION */
#include <stdint.h>
#include <stdlib.h>

/* FreeRTOS includes */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"

/* Our minimal library */
#include "minilib.h"

/* ==================== CONFIGURATION ==================== */
#define TASK_STACK_SIZE  (configMINIMAL_STACK_SIZE * 4)  /* Increased stack */

/* ==================== GLOBAL VARIABLES ==================== */
static SemaphoreHandle_t xMutex;
static SemaphoreHandle_t xMutexA, xMutexB;
static int allocated_memory_count = 0;
static QueueHandle_t xQueue;

/* ==================== HOOK FUNCTIONS ==================== */
void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    (void)xTask;
    printf("\n!!! STACK OVERFLOW in task: %s !!!\n", pcTaskName);
    while(1);
}

void vApplicationMallocFailedHook(void)
{
    printf("\n!!! MALLOC FAILED - Increase configTOTAL_HEAP_SIZE !!!\n");
    while(1);
}

/* Assert function */
void vAssertCalled(const char *pcFile, unsigned long ulLine)
{
    printf("\n!!! ASSERT FAILED: %s:%lu !!!\n", pcFile, ulLine);
    while(1);
}

/* ==================== TASK FUNCTIONS ==================== */

/* 1. Basic multitasking */
static void vTask1(void *pvParameters)
{
    int count = 0;
    while(1)
    {
        printf("[Task1] Counter: %d\n", count++);
        vTaskDelay(1000 / portTICK_PERIOD_MS);  /* Run every 1 second */
    }
}

static void vTask2(void *pvParameters)
{
    int count = 0;
    while(1)
    {
        printf("[Task2] Counter: %d\n", count++);
        vTaskDelay(1500 / portTICK_PERIOD_MS);  /* Run every 1.5 seconds */
    }
}

/* 2. Mutex demo - PROPER SYNCHRONIZATION */
static void vMutexTask1(void *pvParameters)
{
    int count = 0;
    while(1)
    {
        printf("[Mutex1] Waiting for mutex...\n");
        if(xSemaphoreTake(xMutex, portMAX_DELAY) == pdTRUE)
        {
            printf("[Mutex1] >>> CRITICAL SECTION START (count: %d)\n", count++);
            vTaskDelay(200 / portTICK_PERIOD_MS);  /* Simulate work */
            printf("[Mutex1] <<< CRITICAL SECTION END\n");
            xSemaphoreGive(xMutex);
        }
        vTaskDelay(1000 / portTICK_PERIOD_MS);  /* Wait before next attempt */
    }
}

static void vMutexTask2(void *pvParameters)
{
    int count = 0;
    while(1)
    {
        printf("[Mutex2] Waiting for mutex...\n");
        if(xSemaphoreTake(xMutex, portMAX_DELAY) == pdTRUE)
        {
            printf("[Mutex2] >>> CRITICAL SECTION START (count: %d)\n", count++);
            vTaskDelay(300 / portTICK_PERIOD_MS);  /* Simulate work */
            printf("[Mutex2] <<< CRITICAL SECTION END\n");
            xSemaphoreGive(xMutex);
        }
        vTaskDelay(1200 / portTICK_PERIOD_MS);  /* Wait before next attempt */
    }
}

/* 3. Deadlock demo - WITH SAFETY MECHANISM */
static void vDeadlockTask1(void *pvParameters)
{
    int count = 0;
    while(1)
    {
        printf("[Deadlock1] Cycle %d: Taking Mutex A...\n", count);
        
        /* Try with timeout instead of portMAX_DELAY */
        if(xSemaphoreTake(xMutexA, 1000 / portTICK_PERIOD_MS) == pdTRUE)
        {
            printf("[Deadlock1] Got Mutex A. Working...\n");
            vTaskDelay(50 / portTICK_PERIOD_MS);
            
            printf("[Deadlock1] Trying Mutex B (timeout: 500ms)...\n");
            if(xSemaphoreTake(xMutexB, 500 / portTICK_PERIOD_MS) == pdTRUE)
            {
                printf("[Deadlock1] SUCCESS: Got both mutexes!\n");
                vTaskDelay(200 / portTICK_PERIOD_MS);
                
                xSemaphoreGive(xMutexB);
                xSemaphoreGive(xMutexA);
                printf("[Deadlock1] Released both mutexes.\n");
            }
            else
            {
                printf("[Deadlock1] TIMEOUT: Couldn't get Mutex B. Releasing A.\n");
                xSemaphoreGive(xMutexA);  /* Release to avoid deadlock */
            }
        }
        else
        {
            printf("[Deadlock1] Failed to get Mutex A\n");
        }
        
        count++;
        printf("[Deadlock1] Waiting 3 seconds...\n\n");
        vTaskDelay(3000 / portTICK_PERIOD_MS);
    }
}

static void vDeadlockTask2(void *pvParameters)
{
    int count = 0;
    vTaskDelay(100 / portTICK_PERIOD_MS);  /* Start slightly later */
    
    while(1)
    {
        printf("[Deadlock2] Cycle %d: Taking Mutex B...\n", count);
        
        if(xSemaphoreTake(xMutexB, 1000 / portTICK_PERIOD_MS) == pdTRUE)
        {
            printf("[Deadlock2] Got Mutex B. Working...\n");
            vTaskDelay(30 / portTICK_PERIOD_MS);
            
            printf("[Deadlock2] Trying Mutex A (timeout: 500ms)...\n");
            if(xSemaphoreTake(xMutexA, 500 / portTICK_PERIOD_MS) == pdTRUE)
            {
                printf("[Deadlock2] SUCCESS: Got both mutexes!\n");
                vTaskDelay(150 / portTICK_PERIOD_MS);
                
                xSemaphoreGive(xMutexA);
                xSemaphoreGive(xMutexB);
                printf("[Deadlock2] Released both mutexes.\n");
            }
            else
            {
                printf("[Deadlock2] TIMEOUT: Couldn't get Mutex A. Releasing B.\n");
                xSemaphoreGive(xMutexB);  /* Release to avoid deadlock */
            }
        }
        else
        {
            printf("[Deadlock2] Failed to get Mutex B\n");
        }
        
        count++;
        printf("[Deadlock2] Waiting 3 seconds...\n\n");
        vTaskDelay(3000 / portTICK_PERIOD_MS);
    }
}

/* 4. Memory management - SAFE ALLOCATION */
static void vMemoryTask(void *pvParameters)
{
    int alloc_count = 0;
    while(1)
    {
        printf("[Memory] Attempting allocation #%d...\n", alloc_count + 1);
        void *ptr = pvPortMalloc(64);  /* Smaller allocation */
        
        if(ptr != NULL)
        {
            allocated_memory_count++;
            alloc_count++;
            printf("[Memory] ✓ Allocated 64 bytes (total active: %d)\n", allocated_memory_count);
            
            vTaskDelay(500 / portTICK_PERIOD_MS);  /* Use memory */
            
            vPortFree(ptr);
            allocated_memory_count--;
            printf("[Memory] ✓ Freed memory (total active: %d)\n", allocated_memory_count);
        }
        else
        {
            printf("[Memory] ✗ Allocation failed! Heap might be full.\n");
        }
        
        vTaskDelay(2000 / portTICK_PERIOD_MS);  /* Wait before next allocation */
    }
}

/* 5. Priority scheduling - ALL PRIORITIES */
static void vLowPriorityTask(void *pvParameters)
{
    int count = 0;
    while(1)
    {
        printf("[Low-Priority] Running #%d\n", ++count);
        vTaskDelay(4000 / portTICK_PERIOD_MS);  /* Run every 4 seconds */
    }
}

static void vMediumPriorityTask(void *pvParameters)
{
    int count = 0;
    while(1)
    {
        printf("[Medium-Priority] Running #%d\n", ++count);
        vTaskDelay(2500 / portTICK_PERIOD_MS);  /* Run every 2.5 seconds */
    }
}

static void vHighPriorityTask(void *pvParameters)
{
    int count = 0;
    while(1)
    {
        printf("[High-Priority] Running #%d\n", ++count);
        vTaskDelay(1000 / portTICK_PERIOD_MS);  /* Run every 1 second */
    }
}

/* ==================== MAIN FUNCTION ==================== */
int main(void)
{
    printf("\n");
    printf("========================================\n");
    printf("    FreeRTOS OS Concepts Demo\n");
    printf("    All Concepts: Working Version\n");
    printf("========================================\n\n");

    printf("DEMONSTRATING:\n");
    printf("1. Basic Multitasking (Task1, Task2)\n");
    printf("2. Mutex Synchronization (Mutex1, Mutex2)\n");
    printf("3. Deadlock Scenario with Timeout (Deadlock1, Deadlock2)\n");
    printf("4. Dynamic Memory Management (Memory Task)\n");
    printf("5. Priority Scheduling (Low, Medium, High)\n");
    printf("========================================\n\n");

    /* Initialize system */
    printf("Initializing system...\n");

    /* Create mutexes with error checking */
    printf("Creating mutexes...\n");
    xMutex = xSemaphoreCreateMutex();
    if (xMutex == NULL) {
        printf("ERROR: Failed to create main mutex!\n");
        while(1);  /* Add this - infinite loop on error */
    }

    xMutexA = xSemaphoreCreateMutex();
    if (xMutexA == NULL) {
        printf("ERROR: Failed to create Mutex A!\n");
        while(1);
    }

    xMutexB = xSemaphoreCreateMutex();
    if (xMutexB == NULL) {
        printf("ERROR: Failed to create Mutex B!\n");
        while(1);
    }

    printf("Mutexes created successfully.\n\n");

    /* Create all tasks */
    printf("Creating tasks...\n");

    xTaskCreate(vTask1, "Task1", TASK_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(vTask2, "Task2", TASK_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(vMutexTask1, "Mutex1", TASK_STACK_SIZE, NULL, 2, NULL);
    xTaskCreate(vMutexTask2, "Mutex2", TASK_STACK_SIZE, NULL, 2, NULL);
    xTaskCreate(vDeadlockTask1, "Deadlock1", TASK_STACK_SIZE, NULL, 2, NULL);
    xTaskCreate(vDeadlockTask2, "Deadlock2", TASK_STACK_SIZE, NULL, 2, NULL);
    xTaskCreate(vMemoryTask, "Memory", TASK_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(vLowPriorityTask, "Low", TASK_STACK_SIZE, NULL, 1, NULL);
    xTaskCreate(vMediumPriorityTask, "Medium", TASK_STACK_SIZE, NULL, 2, NULL);
    xTaskCreate(vHighPriorityTask, "High", TASK_STACK_SIZE, NULL, 3, NULL);

    printf("All tasks created successfully!\n");
    printf("Starting FreeRTOS scheduler...\n");
    printf("========================================\n\n");

    /* Start the scheduler */
    vTaskStartScheduler();

    /* Should never reach here */
    printf("ERROR: Scheduler exited unexpectedly!\n");
    while(1);

    return 0;
}
