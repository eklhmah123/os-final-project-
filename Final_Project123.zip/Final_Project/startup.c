/* startup.c - Cortex-M3 startup code for QEMU */

#include <stdint.h>

/* External symbols from linker script */
extern uint32_t _estack;
extern uint32_t _sdata, _edata, _sidata;
extern uint32_t _sbss, _ebss;
extern int main(void);

/* Function prototypes */
void Reset_Handler(void);
void Default_Handler(void);

/* Vector table */
__attribute__((section(".vectors")))
void (* const vector_table[])(void) = {
    (void *)&_estack,           /* Initial stack pointer */
    Reset_Handler,              /* Reset handler */
    Default_Handler,            /* NMI handler */
    Default_Handler,            /* Hard fault handler */
    Default_Handler,            /* Memory management fault */
    Default_Handler,            /* Bus fault */
    Default_Handler,            /* Usage fault */
    0, 0, 0, 0,                /* Reserved */
    Default_Handler,            /* SVCall */
    Default_Handler,            /* Debug monitor */
    0,                         /* Reserved */
    Default_Handler,            /* PendSV */
    Default_Handler,            /* SysTick */
    /* External interrupts */
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler,
    Default_Handler, Default_Handler, Default_Handler, Default_Handler
};

/* Reset handler */
void Reset_Handler(void) {
    /* Copy data from flash to RAM */
    uint32_t *src = &_sidata;
    uint32_t *dst = &_sdata;
    while (dst < &_edata) {
        *dst++ = *src++;
    }
    
    /* Zero out BSS section */
    dst = &_sbss;
    while (dst < &_ebss) {
        *dst++ = 0;
    }
    
    /* Call SystemInit if defined */
    SystemInit();
    
    /* Call main */
    main();
    
    /* If main returns, loop forever */
    while (1);
}

/* Default handler for unused interrupts */
void Default_Handler(void) {
    while (1);
}

/* Minimal SystemInit */
void SystemInit(void) {
 /* Nothing - FreeRTOS will configure everything */



}
