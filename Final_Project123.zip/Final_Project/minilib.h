/* minilib.h */
#ifndef MINILIB_H
#define MINILIB_H

/* Simple output functions */
void _putchar(char c);
int puts(const char *s);
int printf(const char *format, ...);

#endif
