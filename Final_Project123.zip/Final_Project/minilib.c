#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>

/* QEMU LM3S6965 UART0 address */
#define UART0_BASE 0x4000C000UL

/* Simple character output to UART */
void debug_putc(char c)
{
    /* Write character to UART0 data register */
    volatile uint32_t *uart_data = (volatile uint32_t *)UART0_BASE;
    *uart_data = (uint32_t)c;
}

/* String output function */
int debug_puts(const char *str)
{
    int count = 0;
    while (*str) {
        debug_putc(*str++);
        count++;
    }
    debug_putc('\n');  /* Add newline */
    return count + 1;
}

/* ========== STANDARD printf/puts FUNCTIONS ========== */

/* puts - standard library function */
int puts(const char *str)
{
    return debug_puts(str);
}

/* putchar - standard library function */
int putchar(int c)
{
    debug_putc((char)c);
    return c;
}

/* printf - simple implementation */
int printf(const char *format, ...)
{
    va_list args;
    va_start(args, format);
    
    char buffer[32];
    const char *p = format;
    int count = 0;
    
    while (*p) {
        if (*p == '%') {
            p++;
            if (*p == 's') {
                /* Handle %s */
                char *str = va_arg(args, char*);
                while (str && *str) {
                    debug_putc(*str++);
                    count++;
                }
            } else if (*p == 'd' || *p == 'i') {
                /* Handle %d or %i */
                int num = va_arg(args, int);
                char num_buf[16];
                char *ptr = num_buf;
                int is_negative = 0;
                
                if (num < 0) {
                    is_negative = 1;
                    num = -num;
                }
                
                do {
                    *ptr++ = '0' + (num % 10);
                    num /= 10;
                } while (num);
                
                if (is_negative) {
                    *ptr++ = '-';
                }
                
                *ptr = '\0';
                
                /* Reverse the string */
                char *start = num_buf;
                char *end = ptr - 1;
                while (start < end) {
                    char temp = *start;
                    *start = *end;
                    *end = temp;
                    start++;
                    end--;
                }
                
                /* Output the number */
                for (char *b = num_buf; *b; b++) {
                    debug_putc(*b);
                    count++;
                }
            } else if (*p == 'c') {
                /* Handle %c */
                char ch = (char)va_arg(args, int);
                debug_putc(ch);
                count++;
            } else if (*p == '%') {
                /* Handle %% */
                debug_putc('%');
                count++;
            } else {
                /* Unknown format, just output */
                debug_putc('%');
                if (*p) {
                    debug_putc(*p);
                    count++;
                }
            }
        } else {
            debug_putc(*p);
            count++;
        }
        if (*p) p++;
    }
    
    va_end(args);
    return count;
}

/* _putchar - alias for putchar */
void _putchar(char c)
{
    debug_putc(c);
}

/* ========== STANDARD C LIBRARY FUNCTIONS ========== */

/* memset - required by FreeRTOS */
void *memset(void *s, int c, size_t n)
{
    unsigned char *p = s;
    while (n-- > 0) *p++ = (unsigned char)c;
    return s;
}

/* memcpy - required by FreeRTOS */
void *memcpy(void *dest, const void *src, size_t n)
{
    unsigned char *d = dest;
    const unsigned char *s = src;
    while (n-- > 0) *d++ = *s++;
    return dest;
}

/* memmove */
void *memmove(void *dest, const void *src, size_t n)
{
    unsigned char *d = dest;
    const unsigned char *s = src;

    if (d < s) {
        while (n-- > 0) *d++ = *s++;
    } else {
        d += n;
        s += n;
        while (n-- > 0) *--d = *--s;
    }
    return dest;
}

/* memcmp */
int memcmp(const void *s1, const void *s2, size_t n)
{
    const unsigned char *p1 = s1, *p2 = s2;
    while (n-- > 0) {
        if (*p1 != *p2) return *p1 - *p2;
        p1++; p2++;
    }
    return 0;
}

/* strcpy */
char *strcpy(char *dest, const char *src)
{
    char *d = dest;
    while ((*d++ = *src++) != '\0');
    return dest;
}

/* strlen */
size_t strlen(const char *str)
{
    size_t len = 0;
    while (str[len] != '\0') len++;
    return len;
}

/* strcmp */
int strcmp(const char *s1, const char *s2)
{
    while (*s1 && (*s1 == *s2)) {
        s1++; s2++;
    }
    return *(unsigned char *)s1 - *(unsigned char *)s2;
}

/* strncmp */
int strncmp(const char *s1, const char *s2, size_t n)
{
    while (n && *s1 && (*s1 == *s2)) {
        s1++; s2++; n--;
    }
    if (n == 0) return 0;
    return *(unsigned char *)s1 - *(unsigned char *)s2;
}

/* strchr */
char *strchr(const char *s, int c)
{
    while (*s != (char)c) {
        if (*s == '\0') return NULL;
        s++;
    }
    return (char *)s;
}

/* Convert integer to string */
char *debug_itoa(int value, char *str, int base)
{
    char *ptr = str, *ptr1 = str, tmp_char;
    int tmp_value;

    if (base < 2 || base > 36) {
        *ptr = '\0';
        return str;
    }

    do {
        tmp_value = value;
        value /= base;
        *ptr++ = "0123456789abcdefghijklmnopqrstuvwxyz"[tmp_value - value * base];
    } while (value);

    if (tmp_value < 0) *ptr++ = '-';
    *ptr-- = '\0';

    while (ptr1 < ptr) {
        tmp_char = *ptr;
        *ptr-- = *ptr1;
        *ptr1++ = tmp_char;
    }

    return str;
}

/* Convert unsigned integer to string */
char *debug_utoa(unsigned int value, char *str, int base)
{
    char *ptr = str, *ptr1 = str, tmp_char;
    unsigned int tmp_value;

    if (base < 2 || base > 36) {
        *ptr = '\0';
        return str;
    }

    do {
        tmp_value = value;
        value /= base;
        *ptr++ = "0123456789abcdefghijklmnopqrstuvwxyz"[tmp_value - value * base];
    } while (value);

    *ptr-- = '\0';

    while (ptr1 < ptr) {
        tmp_char = *ptr;
        *ptr-- = *ptr1;
        *ptr1++ = tmp_char;
    }

    return str;
}

/* ========== NEWLIB STUBS ========== */

/* _sbrk - heap memory allocation */
void *_sbrk(int incr)
{
    extern char _end; /* Defined by linker */
    extern char _heap_end; /* Defined by linker */
    static char *heap_end = &_end;
    char *prev_heap_end;

    prev_heap_end = heap_end;

    if (heap_end + incr > &_heap_end) {
        return (void *)-1; /* Out of memory */
    }

    heap_end += incr;
    return (void *)prev_heap_end;
}

/* _write - for printf */
int _write(int file, char *ptr, int len)
{
    int i;
    for (i = 0; i < len; i++) {
        debug_putc(ptr[i]);
    }
    return len;
}

/* _read - stub */
int _read(int file, char *ptr, int len)
{
    return 0;
}

/* _close - stub */
int _close(int file)
{
    return -1;
}

/* _fstat - stub */
int _fstat(int file, void *st)
{
    return 0;
}

/* _isatty - stub */
int _isatty(int file)
{
    return 1;
}

/* _lseek - stub */
int _lseek(int file, int ptr, int dir)
{
    return 0;
}

/* _exit - stub */
void _exit(int status)
{
    while(1);
}

/* _kill - stub */
int _kill(int pid, int sig)
{
    return -1;
}

/* _getpid - stub */
int _getpid(void)
{
    return 1;
}
